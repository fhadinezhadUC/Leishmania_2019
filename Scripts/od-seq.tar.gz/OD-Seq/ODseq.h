/*
 * OutDet.h
 *
 *  Created on: 8 Apr 2014
 *      Author: peter
 */

#ifndef ODSEQ_H_
#define ODSEQ_H_

using namespace std;

#include "runtimeargs.h"
#include "util.h"
#include "AliReader.h"
#include "DistCalc.h"
#include "DistWriter.h"
#include "Bootstrap.h"
#include "ResultWriter.h"
#include "FastaWriter.h"

#endif /* ODSEQ_H_ */
